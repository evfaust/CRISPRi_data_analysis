import os
import argparse
import pathlib
import math
import h5py
import multiprocessing as mp
import time
import csv
from Bio import SeqIO
from decimal import Decimal

if __name__ == '__main__':
	parser = argparse.ArgumentParser(description='Preprocesses data from basecalled fast5 files')
	parser.add_argument('-f', '--file', type=pathlib.Path, help='.tsv file from USEARCH')
	parser.add_argument('-d', '--design', type=pathlib.Path, help='design file in FASTA format')
	parser.add_argument('-c', '--readcounts', type=int, help='total reads against which to normalize')
	parser.add_argument('-o', '--output', type=str, help='name of output .tsv file')
	args = parser.parse_args()
	count = 0
	diagList = []
	designSet = set()
	for record in SeqIO.parse(args.design, 'fasta'):
		designSet.add(str(record.id))

	finalDataDict = {}
	for design in designSet:
		finalDataDict[design] = 0

	with open(args.file, 'r') as inCsv:
		read = csv.reader(inCsv, delimiter='\t')
		for row in read:
			matchID = float(row[2])
			cassette = row[1]

			if matchID == 100.0:
				finalDataDict[cassette] += 1
			if cassette == 'pWGA128_escapeControl':
				diagList.append(row)
			count += 1
			if count % 100000 == 0:
				print('[readCounter] %i lines processed' % count)

	with open('./' + args.output + '.tsv', 'w+') as outFile:
		print('design\tcounts\tabundance', file=outFile)
		for key, value in finalDataDict.items():
			prop = '%.5E' % Decimal(value/args.readcounts)
			print('%s\t%i\t%s' % (key, value, prop), file=outFile)
	if len(diagList) > 0:
		with open('./diagnostics.tsv', 'w+') as diagOut:
			for i in diagList:
				print(i, file=diagOut)


exit()


