def test_function():
    return "Hello, world!"